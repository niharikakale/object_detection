const dropArea = document.getElementById("drop-area");
const inputFile = document.getElementById("input-file");
const imageView = document.getElementById("img-view");

inputFile.addEventListener("change", uploadImage);

function uploadImage(){
    if(inputFile.files.length > 0) {
        let imgLink = URL.createObjectURL(inputFile.files[0]);
        imageView.style.backgroundImage = `url('${imgLink}')`;
        imageView.textContent = "";
        imageView.style.border = "0";
    }
}

// Corrected event name to "dragover"
dropArea.addEventListener("dragover", function(e){
    e.preventDefault();
    dropArea.classList.add("drag-over"); // Optional: for visual feedback
});

dropArea.addEventListener("drop", function(e){
    e.preventDefault();
    dropArea.classList.remove("drag-over"); // Optional: for visual feedback

    if(e.dataTransfer.files.length) {
        const files = e.dataTransfer.files;
        // Assuming you want to handle only the first file similar to the input change event
        inputFile.files = files; // This direct assignment will not work, see explanation
        // Manual upload trigger since direct assignment is not feasible
        let imgLink = URL.createObjectURL(files[0]);
        imageView.style.backgroundImage = `url('${imgLink}')`;
        imageView.textContent = "";
        imageView.style.border = "0";
    }
});

// Note: Directly setting inputFile.files won't work due to the read-only nature of the files property.
// As a workaround, you might need a manual approach or trigger the file input programmatically for the user to select files, but it won't handle dropped files directly.
